package com.example.demo.repositories;

import org.springframework.stereotype.Repository;

import com.example.demo.models.ProductDTO;

import org.springframework.data.mongodb.repository.MongoRepository;


@Repository
public interface  IProductDAO  extends MongoRepository<ProductDTO, String> {
	
	
}